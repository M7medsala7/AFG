
function markNotificationAsRead()
{
    $.get('/markAsRead');
}


