<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");   
 // header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
 header('Access-Control-Allow-Credentials: true');
  
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});


Route::get('skills', 'apicontroller@allskills');
Route::get('countries', 'apicontroller@allcountry');
Route::get('industries', 'apicontroller@allidustry');
Route::get('currencies', 'apicontroller@allcurrency');
Route::get('religion', 'apicontroller@allreligion');
Route::get('jobs', 'apicontroller@alljobs');
Route::get('employer_type', 'apicontroller@employertype');
Route::get('exprience', 'apicontroller@allexprience');
Route::get('top_candidate', 'apicontroller@topcandidate');
Route::get('nationality', 'apicontroller@allnationality');
Route::get('language', 'apicontroller@language');

Route::post('login', 'apicontroller@login');
Route::post('searchjobs', 'apicontroller@searchjobs');
Route::post('cities', 'apicontroller@allcity');
Route::post('viewjob', 'apicontroller@viewjob');
Route::post('viewprofile', 'apicontroller@viewprofile');
Route::post('revlant_jobs', 'apicontroller@revlantjob');
Route::post('register_candidate', 'apicontroller@easycanreg');
Route::post('updateimage', 'apicontroller@updateimage');
Route::post('updatemainvideo', 'apicontroller@updatemainvideo');
Route::post('newvideo', 'apicontroller@newvideo');
Route::post('deletevideo', 'apicontroller@deletevideo');
Route::post('employer_registation', 'apicontroller@employerregistation');
Route::post('revlant_withoutreg', 'apicontroller@revlantjobwithoutReg');
Route::post('update_Candidate', 'apicontroller@updateFullReg');
Route::post('Company', 'apicontroller@Company');
Route::post('save_job', 'apicontroller@savejob');
Route::post('favourite_candidate', 'apicontroller@likecandidate');
Route::post('get_favourite_job', 'apicontroller@yourfavouritejobs');
Route::post('get_favourite_candidate', 'apicontroller@favouritecan');
Route::post('job_by_employer', 'apicontroller@jobbyemployer');
Route::post('candidate_Videos', 'apicontroller@candidateVideos');
Route::post('search_candidate', 'apicontroller@searchcandidate');

Route::post('add_sucessstory_Emp', 'apicontroller@addsucessstoryEmp');
Route::post('add_sucessstory_Can', 'apicontroller@addsucessstoryCan');
Route::get('get_all_sucess', 'apicontroller@getallsucess');
Route::post('get_sucess_byuser', 'apicontroller@getsucessbyuser');

Route::post('get_jobs_application','apicontroller@getappliesjob');
Route::post('applyjob','apicontroller@applyjob');

Route::post('post_job','apicontroller@postjob');
Route::post('confirmation_mail','apicontroller@confirmationmail');





















