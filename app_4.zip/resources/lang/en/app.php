<?php

return [

        'allemp'=>'all employer ',
        'allcan'=>'All Candidate',
        'jobs'=>'jobs',
        'Home'=> 'Home',
        'Request'=>'request',
        'Pricing'=>'Pricing',
        'Blogs'=>'Blogs',
        'Logout'=>'Log out',
        'messages'=>'messages',
        'interviews'=>'interviews',
        'Account'=>'Account',
        'login'=>'login',
        'Register'=>'Register',
        'Successstories'=>'Success stories',
        'more'=>'View more ',
        'IamCandidate'=>'I am Candidate',
        'IAmEmployer'=>'I Am Employer',
        
        // --------------------footer----------------------------
        'rights'=>' All rights reserved ',
        'ContactUs'=>'Contact Us',
        'About'=>'About',
        'finduson'=>'find us on',
        
         // --------------------index----------------------------
      
         'find_a_job_easily'=>'find a job easily',
         'reach_your_employer_directly'=>'reach your employer directly',
         'forget_about_agencies_hassle'=>'forget about agencies hassle',
         'Find_a_job'=>'Find a job',
         'Find_a_job'=>'Find a job',
         'post_job_you_want_easily'=>'post job you want easily',
         'forget_about_costly_agencie'=>'forget about costly agencie',
         'post_a_job'=>' post a job' ,
         'find_the_most_suitable'=>'find the most suitable'
         // -----------------------------section 2 in index --------------------
         ,'recently_added_jobs'=>' recently added jobs ',
         'view_job'=>'view job',
         'view_more_jobs'=>'view more jobs',
    // -----------------------------section 3 in index --------------------
          'top_Candidate'=>'top Candidate',
          'View_Profile'=>'View_Profile ',
          'view_more_Candidates'=>'view more Candidates',
          
    // -----------------------------section 4 in index --------------------
         
         'start_now'=>'start now',
         'how_it_works'=>'how it works',
         'view_more_testimonials'=>'view more testimonials',
         
         //---------------------Search-----------------------
         'results'=>'results',
         'Job_Title'=>'Job Title',
         'filters'=>'filters',
         'Show_more'=>'Show more',
         'employer_type'=>'employer type',
         'all'=>'all',
         'Desired_Location'=>'Desired Location',
         'None'=>'None',
         'experince'=>'experince',
         'salary'=>'salary',
         'Nationality'=>'Nationality',
         
         'Candidate_Location'=>'Candidate Location',
         'currency'=>'currency',
         'Skills'=>'Skills',
         'Watch_Video'=>'Watch Video',
          'Video'=>'Video',
          //--------------------about us -----------------
          'looking_for_a_job'=>'looking_for_a_job',
          'signup'=>'signup',
          'here'=>'here',
           //   ---------------------------------View job-------------------
        "apply"=>'apply',
        "Applied"=>'Applied ',
        "appl_without"=>' appl without',
        'apply_now'=>'apply now ',
        'job_discription'=>'job discription ',
        'job_Requirements'=>'job Requirements ',
        'industry'=>'industry',
        'skills'=>'skills',
        'About_company'=>'About company ',
        'more_jobs_from_company'=>'  more jobs from company',
        'similar_jobs'=>'similar jobs ',
        'record_your'=>' record your',
        'video_now'=>'video now',
          //----------------Request -------------------
          'you_Can_submit_your_request'=>'you Can submit your request',
          'Name'=>'Name',
          'email_address'=>'email address',
          'phone_number'=>'phone number',
          'submit'=>'submit',
          'your_massage'=>'your massage',
          'Our_contact'=>'Our_contact',
          'email'=>'email',
          'Address'=>'Address',
          'Password'=>'Password',
          'Remember_Me'=>'Remember Me',
          'Forgot_Your_Password'=>'Forgot Your Password',
          'sign_in_with'=>'sign in with',
          'login_now'=>'login now',
          'create_new_account_in_3_Steps'=>'create new account in 3 Steps',
          'Register_With'=>'Register With',
            //-----------------------profile -----------------------
        'candidate_profile'=>'candidate profile',
        'current_loaction'=>'current loaction',
        'visa_status'=>'visa status',
        'call'=>'call',
        'message'=>'message',
        'View_Cv'=>'View Cv',
        'language'=>'language',
        'No_skills_selected'=>'No skills selected',
        'No_Languages_Selected'=>'No Languages Selected',
        'education'=>'education',
        'work_experience'=>'work experience',
        'available'=>'available',
        'profile'=>'profile',
        'Similar_candidates'=>'Similar candidates',
        'call_now'=>'call now',
        'login_to_Maidandhelper'=>'login to Maidandhelper',
        
          
          
         
         
         
         
         
         
        
       
        
     
   

];
