<center>
<div class="text-center">
                               
                     <p class="lead" style="font-family: 'Cairo', sans-serif;     font-size: 17px;    font-weight: bold;"> 
                       تم الحجز بنجاح ...شكرا لاستخدامك يلا احجز
                      <br>
                         للاستفسارات والمشاكل الفنية يمكنكم مراسلة الدعم الفني على 
                         <br>
                        
                         Support@YallaE7gez.com

                                <br>
                         
                                     
                                </p>
                 
                           
                            </div>
                            </center>