
<center>
<div class="text-center">
                               
                     <p class="lead" style="font-family: 'Cairo', sans-serif;    font-size: 17px;   font-weight: bold;"> 
                                تم تسجيل البيانات بنجاح في خدمة يلا احجز
                         <br>
                         سيتم مراجعة البيانات من قبل الادارة وتفعيل الحساب الخاص بكم خلال 48 ساعة
                        <br>
                         للاستفسارات يمكنكم مراسلتنا على 
                         <br>
                         Support@YallaE7gez.com   

                            </p>
                 
                           
                            </div>
                       </center>