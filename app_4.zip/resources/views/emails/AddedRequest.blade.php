<!DOCTYPE html>
<html>
<head>
<style>
div.gallery {
    margin: 0px;
  
    float: left;
    width: 180px;
}

div.gallery:hover {
    border: 1px solid #777;
}

div.gallery img {
    width: 100%;
    height: 200px;
}

div.desc {
    padding: 1px;
    text-align: center;
}
</style>
</head>
<body>
<table style="  border-collapse:collapse;">
<tr>
<td>
<div class="gallery">
  <a target="_blank" href="https://www.maidandhelper.com/">
    <img src="https://www.maidandhelper.com/images/P7.PNG" alt="5Terre" width="600" height="400">
  </a>
 
</div>
</td>
<td>
<div class="gallery">
  <a target="_blank" href="https://www.maidandhelper.com/">
    <img src="https://www.maidandhelper.com/images/P6.PNG" alt="Forest" width="600" height="400">
  </a>
  
</div>
</td>
<td>
<div class="gallery">
  <a target="_blank" href="https://www.maidandhelper.com/">
    <img src="https://www.maidandhelper.com/images/p3.PNG" alt="Northern Lights" width="600" height="400">
  </a>
 
</div>
</td>
</tr>
<tr>
<td>
<div class="gallery">
  <a target="_blank" href="https://www.maidandhelper.com/">
    <img src="https://www.maidandhelper.com/images/c1.PNG" alt="5Terre" width="600" height="400">
  </a>
 
</div>
</td>
<td>
<div class="gallery">
  <a target="_blank" href="https://www.maidandhelper.com/">
    <img src="https://www.maidandhelper.com/images/c2.PNG" alt="Forest" width="600" height="400">
  </a>
  
</div>
</td>
<td>
<div class="gallery">
  <a target="_blank" href="https://www.maidandhelper.com/">
    <img src="https://www.maidandhelper.com/images/c7.PNG" alt="Northern Lights" width="600" height="400">
  </a>
 
</div>
</td>
</tr>
</table>
<p>Dear Admin, </p>
<p>You Have Anew Request is Added <br></p>
<p>Please <button style="background-color:#5DADE2;">  <a  target="_blank"  href="https://www.maidandhelper.com/login" style="text-decoration:none;">Click Here ,Start your journy </a></button>

.</p><br>
<p>Regards,<br>
Maid and Helper Team </p>




</body>
</html>
