<center>
<div class="text-center">
                               
                     <p class="lead" style="font-family: 'Cairo', sans-serif;     font-size: 17px;    font-weight: bold;"> 
                      Name:{{$Name}}
                      <br>
                      Phone:  {{$Tele}}  
                         <br>
                        
                      Email: {{$EmailRes}} 

                                <br>
                         Details: {{$Details}} 
                                     
                                </p>
                 
                           
                            </div>
                            </center>