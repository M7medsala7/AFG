<center>
<div class="text-center">
                               
                     <p class="lead" style="font-family: 'Cairo', sans-serif;     font-size: 17px;  font-weight: bold;"> 
                                تم الإشتراك بنجاح وسوف يصلك كل جديد 
                                <br>
                                      
                                </p>
                 
                           
                            </div>
                            </center>