<!DOCTYPE html>
<html>
<head>
<style>
div.gallery {
    margin: 0px;
  
    float: left;
    width: 180px;
}

div.gallery:hover {
    border: 1px solid #777;
}

div.gallery img {
    width: 100%;
    height: 200px;
}

div.desc {
    padding: 1px;
    text-align: center;
}
</style>
</head>
<body>

<p>Dear User, </p>


<p>thanks for your request Regards,<br>
Maid and Helper Team </p>
<a href="https://www.maidandhelper.com/search?type=I+Am+Employer&words=">if you employer</a>
<br>
<br>
<a href="https://www.maidandhelper.com/search?type=I+am+Candidate&words=">if you Candaties</a>


</body>
</html>
