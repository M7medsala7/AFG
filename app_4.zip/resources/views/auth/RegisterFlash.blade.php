<section class="sliderphoto innerphoto" style="background:url(/images/slide5.jpg) fixed center center no-repeat; background-size:cover;">
  <div class="overlaytru">
    <div class="modal-content dal-conte"> <i class="fas fa-check-circle"></i>
      <h2 class="textcandidate">congratulations</h2>
      <p class="viewsdriver">we found a match jobs </p>
      <div class="sk-circle">
       {{ $MatchingJobs->count() }}
      </div>
      <div class="linksing"><a href="a href="/home3"> view more  </a></div>
    </div>
  </div>
  <!--overlaytru--> 
  
</section>
<!--section-->
