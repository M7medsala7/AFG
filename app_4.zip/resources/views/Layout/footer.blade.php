<footer class="footer" style="">
  <div class="container">
  <div class="container">
    <div class="textlogo"><img src="/images/logofot.png" title="Maid & Helper">
      <p>{{trans('app.rights')}}. آ© 2018  Maid & Helper </p>
    </div>
    <nav class="list-inline iconfot"> <a href="https://www.facebook.com/MaidnHelper/" class="fab fa-facebook-f" title="facebook"></a>
     <a href="https://twitter.com/Maidandhelper" class="fab fa-twitter" title="twitter"></a> 
    <a href="https://plus.google.com/s/maidandhelper/" class="fab fa-google-plus-g" title="google-plus"></a> 
    <a href="https://www.instagram.com/maidandhelper/" class="fab fa-instagram" title="instagram"></a> 
    <a href="https://www.youtube.com/channel/UCV7koWYbuWjmKsjQa96_3Qw" class="fab fa-youtube" title="youtube"></a> 
      <!--<a href="#" class="fab fa-snapchat-ghost snapchat" title="snapchat" style="background: #03c12d"></a> 
 <a href="#" class=""fab fa-whatsapp whatsapp" title="whatsapp" style="background: #03c12d"></a>--> 
      
    </nav>
    <nav class="list-unstyled"> <a href="/aboutus">{{trans('app.About')}}  </a> <a href="/contact">  {{trans('app.ContactUs')}} </a> <a href="#">{{trans('app.finduson')}}  </a> </nav>
  </div>
  <!--//.container--> 
  
  <a href="#" class="fa fa-angle-up scrollToTop"></a> </footer>
