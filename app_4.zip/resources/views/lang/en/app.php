<?php

return [

  

    'Home'=> 'الرئيسيه',
    

];
