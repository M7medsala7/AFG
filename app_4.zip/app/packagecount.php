<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class packagecount extends Model
{
   public $table="packagecount";
}
