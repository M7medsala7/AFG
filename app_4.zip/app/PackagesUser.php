<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PackagesUser extends Model
{
   public $table="package_user";
}
