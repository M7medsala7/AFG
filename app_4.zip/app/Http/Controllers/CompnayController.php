<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CompnayController extends Controller
{
    //
    public function create()
    {
	    return view('employer.company_profile');
    	
    }
}
