<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request; 
use App\User; 
use Illuminate\Support\Facades\Auth; 
use Validator;
use App\PostJob;
use App\Religion;
use App\Job;
use App\Country;
use App\Skills;
use App\City;
use App\CandidateInfo;
use App\EmployerProfile;
use DB;
use App\Notifications\Candidate_notification;
use App\Notifications;
use App\Http\Requests\RegisterFormRequest;
use App\Http\Requests\FullCanRegisterFormRequest;
use App\Http\Requests\CanRegisterFormRequest;
use App\Http\Requests\EmpRegisterFormRequest;
use Mail;
use App\Industry;
use App\Nationality;
use App\Currency;
use App\Company;
use App\Exprience;
use App\SuccessStories;
use App\UserLikeCandidates;
use App\Language;
class apicontroller extends Controller 
{
public $successStatus = 200;
/** 
     * login api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function login(Request $request){ 

        if(Auth::attempt(['email' => request('email'), 'password' => request('password')])){ 
            $user = Auth::user(); 


          $userdata=User::where('email',request('email'))
          ->first();
          if($userdata->type=='employer')
          {

           $user=EmployerProfile::with(['country','city'])
          ->join('users','users.id','=','employer_profiles.user_id')
          ->where('user_id', $user->id)
          ->select('*','users.*')
          ->first();
              
          }else
          {
$user=CandidateInfo::with(['country','religion','job','industry','canjob','nationality','CanExperince','getCandidateLang','getCandidatePreferedLoc','skills'])
->join('users','users.id','=','candidate_infos.user_id')
->where('user_id', $user->id)
->select('*','users.*')
->first();
              
          }

          
          
            return response()->json(['user' => $user,"Message"=> "",
        "Success"=>true]); 
        } 
        else{ 
            return response()->json(['error'=>'Unauthorised'], 401); 
        } 
    }
/** 
     * Register api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function register(Request $request) 
    { 
        $validator = Validator::make($request->all(), [ 
            'name' => 'required', 
            'email' => 'required|email', 
            'password' => 'required', 
            'c_password' => 'required|same:password', 
        ]);
if ($validator->fails()) { 
            return response()->json(['error'=>$validator->errors()], 401);            
        }
$input = $request->all(); 
        $input['password'] = bcrypt($input['password']); 
        $user = User::create($input); 
        $success['token'] =  $user->createToken('MyApp')-> accessToken; 
        $success['name'] =  $user->name;
return response()->json(['success'=>$success], $this-> successStatus); 
    }
/** 
     * details api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function details() 
    { 
        $user = Auth::user(); 
        return response()->json(['user' => $user], $this-> successStatus); 
    } 
      public function searchcandidate(Request $request) 
    {
        try{
             if (request('Natinality_id')==0 && request('country_id')== 0 &&
            request('job_id')== "")
            {
              $Data=CandidateInfo::with(['country','religion','job','industry','canjob','nationality','CanExperince','getCandidateLang','getCandidatePreferedLoc','skills'])
                ->join('users','users.id','=','candidate_infos.user_id')
                ->select('*','users.*')
                ->get();
                
              return response()->json(['allcandidate' => $Data,"Message"=> "","Success"=>true]); 
            }
            else if  (request('Natinality_id')!=0 && request('country_id')== 0 &&
            request('job_id')== "")
            {
              $Data=CandidateInfo::with(['country','religion','job','industry','canjob','nationality','CanExperince','getCandidateLang','getCandidatePreferedLoc','skills'])
                ->join('users','users.id','=','candidate_infos.user_id')
                ->where('nationality_id',request('Natinality_id'))
                ->select('*','users.*')
                ->get();
                
              return response()->json(['allcandidate' => $Data,"Message"=> "","Success"=>true]); 
            }
              else if  (request('Natinality_id')==0 && request('country_id')!= 0 &&
            request('job_id')== "")
            {
              $Data=CandidateInfo::with(['country','religion','job','industry','canjob','nationality','CanExperince','getCandidateLang','getCandidatePreferedLoc','skills'])
                ->join('users','users.id','=','candidate_infos.user_id')
                ->where('country_id',request('country_id'))
                ->select('*','users.*')
                ->get();
                
              return response()->json(['allcandidate' => $Data,"Message"=> "","Success"=>true]); 
            }
               else if  (request('Natinality_id')!=0 && request('country_id')!= 0 &&
            request('job_id')== "")
            {
              $Data=CandidateInfo::with(['country','religion','job','industry','canjob','nationality','CanExperince','getCandidateLang','getCandidatePreferedLoc','skills'])
                ->join('users','users.id','=','candidate_infos.user_id')
                ->where('country_id',request('country_id'))
                 ->where('nationality_id',request('Natinality_id'))
                ->select('*','users.*')
                ->get();
                
              return response()->json(['allcandidate' => $Data,"Message"=> "","Success"=>true]); 
            }
            
             //job name
        else if (request('job_id')!= "" && request('Natinality_id')== 0 &&
        request('country_id')== 0  )
         {
            $Matchingcandata=[];
            $JobNameLiks=Job::where('name', 'LIKE', '%'.request('job_id').'%')->get();
            foreach($JobNameLiks as $JobNameLiks)
            {
                $Matchingcan = CandidateInfo::with(['country','religion','job','industry','canjob','nationality','CanExperince','getCandidateLang','getCandidatePreferedLoc','skills'])
                ->join('users','users.id','=','candidate_infos.user_id')
                ->where('job_id',$JobNameLiks->id)
                ->select('*','users.*')
                ->get();
                  
                foreach ($Matchingcan as $Matching) {
                   array_push($Matchingcandata, $Matching); 
                }  
            } 
               return response()->json(['allcandidate' => $Matchingcandata,"Message"=> "","Success"=>true]); 
         }
             //job name
        else if (request('job_id')!= "" && request('Natinality_id')!= 0 &&
        request('country_id')!= 0  )
         {
            $Matchingcandata=[];
            $JobNameLiks=Job::where('name', 'LIKE', '%'.request('job_id').'%')->get();
            foreach($JobNameLiks as $JobNameLiks)
            {
                $Matchingcan = CandidateInfo::with(['country','religion','job','industry','canjob','nationality','CanExperince','getCandidateLang','getCandidatePreferedLoc','skills'])
                ->join('users','users.id','=','candidate_infos.user_id')
                    ->where('country_id',request('country_id'))
                 ->where('nationality_id',request('Natinality_id'))
                ->where('job_id',$JobNameLiks->id)
                ->select('*','users.*')
                ->get();
                  
                foreach ($Matchingcan as $Matching) {
                   array_push($Matchingcandata, $Matching); 
                }  
            } 
               return response()->json(['allcandidate' => $Matchingcandata,"Message"=> "","Success"=>true]); 
         }
               //job name
        else if (request('job_id')!= "" && request('Natinality_id')!= 0 &&
        request('country_id')== 0  )
         {
            $Matchingcandata=[];
            $JobNameLiks=Job::where('name', 'LIKE', '%'.request('job_id').'%')->get();
            foreach($JobNameLiks as $JobNameLiks)
            {
                $Matchingcan = CandidateInfo::with(['country','religion','job','industry','canjob','nationality','CanExperince','getCandidateLang','getCandidatePreferedLoc','skills'])
                ->join('users','users.id','=','candidate_infos.user_id')
               
                 ->where('nationality_id',request('Natinality_id'))
                ->where('job_id',$JobNameLiks->id)
                ->select('*','users.*')
                ->get();
                  
                foreach ($Matchingcan as $Matching) {
                   array_push($Matchingcandata, $Matching); 
                }  
            } 
               return response()->json(['allcandidate' => $Matchingcandata,"Message"=> "","Success"=>true]); 
         }
              //job name
        else if (request('job_id')!= "" && request('Natinality_id')== 0 &&
        request('country_id')!= 0  )
         {
            $Matchingcandata=[];
            $JobNameLiks=Job::where('name', 'LIKE', '%'.request('job_id').'%')->get();
            foreach($JobNameLiks as $JobNameLiks)
            {
                $Matchingcan = CandidateInfo::with(['country','religion','job','industry','canjob','nationality','CanExperince','getCandidateLang','getCandidatePreferedLoc','skills'])
                ->join('users','users.id','=','candidate_infos.user_id')
                    ->where('country_id',request('country_id'))
                
                ->where('job_id',$JobNameLiks->id)
                ->select('*','users.*')
                ->get();
                  
                foreach ($Matchingcan as $Matching) {
                   array_push($Matchingcandata, $Matching); 
                }  
            } 
               return response()->json(['allcandidate' => $Matchingcandata,"Message"=> "","Success"=>true]); 
         }
        }
       catch(Exception $e) 
        {
          return response()->json(['error'=>'error data'], 401);
       }
    }
    
    public function searchjobs(Request $request) 
    {
        try
        {
            if (request('job_id')== "" && request('country_id')== 0 &&
            request('industry_id')== 0 && request('employment_type_id') == 0 &&
            request('experience_id')== 0 && request('salary_from')== 0 
            && request('salary_to')== 0 )
            {
               
              $Data=PostJob::with(['Industry','job','Currency','country','getJobLanguage','getJobSkill'])->get();
              return response()->json(['alljobs' => $Data,"Message"=> "","Success"=>true]); 
            }
          
             //Desired location
            else if (request('job_id')== "" && request('country_id')!= 0 &&
            request('industry_id')== 0 && request('employment_type_id') == 0 &&
            request('experience_id')== 0 && request('salary_from')== 0 
            && request('salary_to')== 0 )
            {
                
                $Data=PostJob::with(['Industry','job','Currency','country','getJobLanguage','getJobSkill'])
                ->where('country_id',request('country_id'))->get();
              return response()->json(['alljobs' => $Data,"Message"=> "","Success"=>true]); 
            }
             //industry
            else if (request('job_id')== "" && request('country_id')== 0 &&
            request('industry_id')!= 0 && request('employment_type_id') == 0 &&
            request('experience_id')== 0 && request('salary_from')== 0 
            && request('salary_to')== 0 )
            {
              
                $Data=PostJob::with(['Industry','job','Currency','country','getJobLanguage','getJobSkill'])
                ->where('industry_id',request('industry_id'))->get();
                return response()->json(['alljobs' => $Data,"Message"=> "","Success"=>true]); 
            }
           //employer
           else if (request('job_id')== "" && request('country_id')== 0 &&
           request('industry_id')== 0 && request('employment_type_id') != 0 &&
           request('experience_id')== 0 && request('salary_from')== 0 
           && request('salary_to')== 0 )
            {
              
                $Data=PostJob::with(['Industry','job','Currency','country','getJobLanguage','getJobSkill'])
                ->where('job_for',request('employment_type_id'))->get();
                  return response()->json(['alljobs' => $Data,"Message"=> "","Success"=>true]); 
            }
        //   --------------------------------------------------
        //salary
        else if (request('job_id')== "" && request('country_id')== 0 &&
        request('industry_id')== 0 && request('employment_type_id') == 0 &&
        request('experience_id')== 0 && request('salary_from')!= 0 
        && request('salary_to')!= 0 )
         {
        
             $Data=PostJob::with(['Industry','job','Currency','country','getJobLanguage','getJobSkill'])
             ->whereBetween('min_salary',[request('salary_from'),request('salary_to')])
            ->whereBetween('max_salary',[request('salary_from'),request('salary_to')])
             ->get();
               return response()->json(['alljobs' => $Data,"Message"=> "","Success"=>true]); 
         }
        //job name
        else if (request('job_id')!= "" && request('country_id')== 0 &&
        request('industry_id')== 0 && request('employment_type_id') == 0 &&
        request('experience_id')== 0 && request('salary_from')== 0 
        && request('salary_to')== 0 )
         {
            $MatchingJobs=[];
            $JobNameLiks=Job::where('name', 'LIKE', '%'.request('job_id').'%')->get();
            foreach($JobNameLiks as $JobNameLiks)
            {
                $MatchingJo = PostJob::with(['Industry','job','Currency','country','getJobLanguage','getJobSkill'])
                ->where('job_id',$JobNameLiks->id)
                ->get();    
                foreach ($MatchingJo as $Matching) {
                   array_push($MatchingJobs, $Matching); 
                }  
            } 
               return response()->json(['alljobs' => $MatchingJobs,"Message"=> "","Success"=>true]); 
         }
 //all have values 
 else if (request('job_id')!= "" && request('country_id')!= 0 &&
        request('industry_id')!= 0 && request('employment_type_id') != 0 &&
        request('experience_id')!= 0 && request('salary_from')!= 0 
        && request('salary_to')!= 0 )
         {
            $MatchingJobs=[];
            $JobNameLiks=Job::where('name', 'LIKE', '%'.request('job_id').'%')->get();
            foreach($JobNameLiks as $JobNameLiks)
            {
                $MatchingJo = PostJob::with(['Industry','job','Currency','country','getJobLanguage','getJobSkill'])
                ->where('job_id',$JobNameLiks->id)
                ->whereBetween('min_salary',[request('salary_from'),request('salary_to')])
                ->whereBetween('max_salary',[request('salary_from'),request('salary_to')])
                ->where('job_for',request('employment_type_id'))
                ->where('industry_id',request('industry_id'))
                ->where('country_id',request('country_id'))
                ->get();    
                foreach ($MatchingJo as $Matching) {
                   array_push($MatchingJobs, $Matching); 
                }  
            } 
               return response()->json(['alljobs' => $MatchingJobs,"Message"=> "","Success"=>true]); 
         }
          
         
 //all have values 
 else if (request('job_id')!= "" && request('country_id')!= 0 &&
        request('industry_id')!= 0 && request('employment_type_id') != 0 &&
        request('experience_id')== 0 && request('salary_from')== 0 
        && request('salary_to')== 0 )
         {
            $MatchingJobs=[];
            $JobNameLiks=Job::where('name', 'LIKE', '%'.request('job_id').'%')->get();
            foreach($JobNameLiks as $JobNameLiks)
            {
                $MatchingJo = PostJob::with(['Industry','job','Currency','country','getJobLanguage','getJobSkill'])
                ->where('job_id',$JobNameLiks->id)
                ->where('job_for',request('employment_type_id'))
                ->where('industry_id',request('industry_id'))
                ->where('country_id',request('country_id'))
                ->get();    
                foreach ($MatchingJo as $Matching) {
                   array_push($MatchingJobs, $Matching); 
                }  
            } 
               return response()->json(['alljobs' => $MatchingJobs,"Message"=> "","Success"=>true]); 
         }
         else if (request('job_id')!= "" && request('country_id')!= 0 &&
         request('industry_id')!= 0 && request('employment_type_id') == 0 &&
         request('experience_id')== 0 && request('salary_from')== 0 
         && request('salary_to')== 0 )
          {
             $MatchingJobs=[];
             $JobNameLiks=Job::where('name', 'LIKE', '%'.request('job_id').'%')->get();
             foreach($JobNameLiks as $JobNameLiks)
             {
                 $MatchingJo = PostJob::with(['Industry','job','Currency','country','getJobLanguage','getJobSkill'])
                 ->where('job_id',$JobNameLiks->id)
                 ->where('industry_id',request('industry_id'))
                 ->where('country_id',request('country_id'))
                 ->get();    
                 foreach ($MatchingJo as $Matching) {
                    array_push($MatchingJobs, $Matching); 
                 }  
             } 
                return response()->json(['alljobs' => $MatchingJobs,"Message"=> "","Success"=>true]); 
          }
          else if (request('job_id')!= "" && request('country_id')!= 0 &&
          request('industry_id')!= 0 && request('employment_type_id') != 0 &&
          request('experience_id')== 0 && request('salary_from')== 0 
          && request('salary_to')== 0 )
           {
              $MatchingJobs=[];
              $JobNameLiks=Job::where('name', 'LIKE', '%'.request('job_id').'%')->get();
              foreach($JobNameLiks as $JobNameLiks)
              {
                  $MatchingJo = PostJob::with(['Industry','job','Currency','country','getJobLanguage','getJobSkill'])
                  ->where('job_id',$JobNameLiks->id)
                  ->where('industry_id',request('industry_id'))
                  ->where('country_id',request('country_id'))
                  ->where('job_for',request('employment_type_id'))
                  ->get();    
                  foreach ($MatchingJo as $Matching) {
                     array_push($MatchingJobs, $Matching); 
                  }  
              } 
                 return response()->json(['alljobs' => $MatchingJobs,"Message"=> "","Success"=>true]); 
           }
           else if (request('job_id')!= "" && request('country_id')== 0 &&
           request('industry_id')!= 0 && request('employment_type_id') != "" &&
           request('experience_id')== 0 && request('salary_from')== 0 
           && request('salary_to')== 0 )
            {
               
               $MatchingJobs=[];
               $JobNameLiks=Job::where('name', 'LIKE', '%'.request('job_id').'%')->get();
               foreach($JobNameLiks as $JobNameLiks)
               {
                   $MatchingJo = PostJob::with(['Industry','job','Currency','country','getJobLanguage','getJobSkill'])
                   ->where('job_id',$JobNameLiks->id)
                   ->where('industry_id',request('industry_id'))
                   ->where('job_for',request('employment_type_id'))
                   ->get();    
                   foreach ($MatchingJo as $Matching) {
                      array_push($MatchingJobs, $Matching); 
                   }  
               } 
                  return response()->json(['alljobs' => $MatchingJobs,"Message"=> "","Success"=>true]); 
            }
          else if (request('job_id')!= "" && request('country_id')!= 0 &&
          request('industry_id')== 0 && request('employment_type_id') == 0 &&
          request('experience_id')== 0 && request('salary_from')== 0 
          && request('salary_to')== 0 )
           {
              $MatchingJobs=[];
              $JobNameLiks=Job::where('name', 'LIKE', '%'.request('job_id').'%')->get();
              foreach($JobNameLiks as $JobNameLiks)
              {
                  $MatchingJo = PostJob::with(['Industry','job','Currency','country','getJobLanguage','getJobSkill'])
                  ->where('job_id',$JobNameLiks->id)
          
                  ->where('country_id',request('country_id'))
                  ->get();    
                  foreach ($MatchingJo as $Matching) {
                     array_push($MatchingJobs, $Matching); 
                  }  
              } 
                 return response()->json(['alljobs' => $MatchingJobs,"Message"=> "","Success"=>true]); 
           }
          

         }
        catch(Exception $e) 
          {
              return response()->json(['error'=>'error data'], 401);
          }
    }
/** 
     * alljobs api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function alljobs() 
    { 
        $Data = Job::all(); 
    return response()->json(['jobs'=>$Data,"Message"=> "","Success"=>true]);
    }
   
     public function company(Request $re) 
    { 
        $Data = Company::with(['Industry','country'])->where('Created_by',$re['Created_by'])->first(); 
    return response()->json(['company'=>$Data,"Message"=> "","Success"=>true]);
    }
    
    public function allidustry() 
    { 
        $Data = Industry::all(); 
        return response()->json(['idustries' => $Data,"Message"=> "",
        "Success"=>true]); 
    }
     public function language() 
    { 
        $Data = Language::all(); 
        return response()->json(['languages' => $Data,"Message"=> "",
        "Success"=>true]); 
    }
    
    
     public function allnationality() 
    { 
        $Data = Nationality::all(); 
        return response()->json(['nationality' => $Data,"Message"=> "",
        "Success"=>true]); 
    }
    public function allcurrency() 
    { 
        $Data = Currency::all(); 
        return response()->json(['currencies' => $Data,"Message"=> "","Success"=>true]); 
    }
     public function candidateVideos(Request $req) 
    { 
        $Data = DB::table('videos')->where('User_Id',$req['User_Id'])->get(); 
        return response()->json(['videos' => $Data,"Message"=> "","Success"=>true]); 
    }
      public function allexprience() 
    { 
        $Data = Exprience::all(); 
        return response()->json(['exprience' => $Data,"Message"=> "","Success"=>true]); 
    }
    
     public function employertype() 
    { 
       
        $Data =PostJob::select('job_for')->orderByRaw('FIELD(job_for, "Family", "Company", "Agency","Jobs In KSA","Jobs In Oman","Jobs In Qatar","Jobs In UAE","Maidcv.Com","Jobs In USA","GulfTalent")','DESC')
 ->distinct('job_for')->get();
        return response()->json(['employer_type' => $Data,"Message"=> "","Success"=>true]); 
    }
    
   
    /** 
     * allcountry api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function allcountry() 
    { 
        $Data = Country::all(); 
       return response()->json(['countries' => $Data,"Message"=> "",
        "Success"=>true]);  
    }
     public function allreligion() 
    { 
        $Data = Religion::all(); 
       return response()->json(['religion.' => $Data,"Message"=> "",
        "Success"=>true]);  
    }
      /** 
     * allskills api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function allskills() 
    { 
        $Data = Skills::all(); 
         return response()->json(['skills' => $Data,"Message"=> "",
        "Success"=>true] );  
    }
        /** 
     * allcity api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
   public function allcity(Request $request)
    { 
         $allcity = City::where('country_id',$request['id'])->get(); 
        return response()->json(['cities' => $allcity,"Message"=> "",
        "Success"=>true] ); 
    }
   /** 
     * viewjobapi 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function viewjob(Request $request)
    { 
        $Data =PostJob::with(['Industry','job','country','getJobLanguage','getJobSkill'])->where('id',$request['job_id'])
               ->first();
       
        
         return response()->json(['job' => $Data,"Message"=> "",
        "Success"=>true] ); 
        
    }
    public function revlantjob(Request $request)
    {
        // to get cand iD to get job id 
        $CandidateInfo=CandidateInfo::where('user_id',$request["can_id"])->first();
        $Data =PostJob::with(['Industry','job','country','getJobLanguage','getJobSkill'])->get();
  
       $MatchingJobs=[];
        $CandidateInfo=CandidateInfo::where('user_id',$request["can_id"])->first();
        //dd($CandidateInfo);
        if($CandidateInfo->job_id!=null)
        {
            //Matching job 

          $JobName=Job::where('id',$CandidateInfo->job_id)->select('name')->first();
        

          $JobNameLiks=Job::where('name', 'LIKE', '%'.$JobName->name.'%')->get();
        foreach($JobNameLiks as $JobNameLiks)
          {
            $MatchingJo = PostJob::with(['Industry','job','Currency','country','getJobLanguage','getJobSkill'])->where('job_id',$JobNameLiks->id)->get();    

          foreach ($MatchingJo as $Matching) {
  
               array_push($MatchingJobs, $Matching); 
   
  
           }  
        }    
        }     
        else
        {

            $MatchingJobs=null;
        } 
        // return $MatchingJobs;
   

        
        
        
       
          return response()->json(['relevant_jobs' => $MatchingJobs,"Message"=> "",
        "Success"=>true]); 
        
        
    }
 /** 
     * viewprofile
     * 
     * @return \Illuminate\Http\Response 
     */ 
  public function viewprofile(Request $request)
    { 
        $Data =CandidateInfo::with(['country','religion','job','industry','canjob','nationality','CanExperince','getCandidateLang','getCandidatePreferedLoc','skills'])
->join('users','users.id','=','candidate_infos.user_id')
->where('user_id', $user->id)
->select('*','users.*')
->first();
        
        if ($Data->CanInfo->birthdate !=null)
        $age=$Data->getAge($Data->CanInfo->birthdate);
        else
        $age="";
  
        $simialr_candidates = CandidateInfo::where('job_id',$Data->CanInfo->job_id)->where('country_id',$Data->CanInfo->country_id)
        ->where('id','!=',$Data->CanInfo->id)->get(); 
       return response()->json(['candidate' => $Data,"Message"=> "","Success"=>true] ); 
    }
     public function jobbyemployer(Request $request)
    { 
        $Data =PostJob::with(['Industry','job','country','getJobLanguage','getJobSkill'])
->where('created_by',$request['user_id'])
->get();
 
       return response()->json(['postedjobs' => $Data,"Message"=> "","Success"=>true] ); 
    }
    public function applyjob(Request $request)
{
    $post_job=PostJob::find($request['job_id']);
    $Like=DB::table('job_applications')
    ->where('job_post_id',$request['job_id'])
    ->where('user_id',$request['user_id'])
    ->first();
    if($Like==null)
    {

    \DB::table('job_applications')->insert(
        array(
               'job_post_id' =>$request['job_id'], 
               'user_id'    =>$request['user_id']
        )
    );
    return response()->json(['data' => [],"Message"=> "apllied Successfully","Success"=>true]); 
    }
    else
    {
        DB::table('job_applications')
    ->where('job_post_id',$request['job_id'])
    ->where('user_id',$request['user_id'])
    ->delete();
       
    return response()->json(['data' => [],"Message"=> "you remove appllied Successfully","Success"=>true]); 
    }
}    
public function savejob(Request $request)
{
    $post_job=PostJob::find($request['job_id']);
    $Like=DB::table('user_like_jobs')
    ->where('job_id',$request['job_id'])
    ->where('user_id',$request['user_id'])
    ->first();
    if($Like==null)
    {

    \DB::table('user_like_jobs')->insert(
        array(
               'job_id' =>$request['job_id'], 
               'user_id'    =>$request['user_id']
        )
    );
    return response()->json(['data' => [],"Message"=> "like Successfully","Success"=>true]); 
    }
    else
    {
        DB::table('user_like_jobs')
    ->where('job_id',$request['job_id'])
    ->where('user_id',$request['user_id'])
    ->delete();
       
    return response()->json(['data' => [],"Message"=> "dislike Successfully","Success"=>true]); 
    }
}    
public function yourfavouritejobs(Request $request)
{
    $Data=[];
    $favourite=DB::table('user_like_jobs')->where('user_id',$request['user_id'])->get();

        foreach ($favourite as $Matching) {
            
            $Dataset=PostJob::with(['Industry','job','country','getJobLanguage','getJobSkill'])
            ->where('id',$Matching->job_id)
            ->first();
            
           array_push($Data, $Dataset); 
        } 

return response()->json(['favouritejobs' => $Data,"Message"=> "","Success"=>true] ); 
}
public function favouritecan(Request $request)
{
    $Data=CandidateInfo::join('user_like_candidates','user_like_candidates.user_id','=','candidate_infos.user_id')
        ->where('user_like_candidates.employer_id',$request['user_id'])
        ->get();
        return response()->json(['favouriteCandidate' => $Data,"Message"=> "",
        "Success"=>true] ); 
}
    public function likecandidate(Request $request)
    {
        $liked = UserLikeCandidates::where('employer_id',$request['employer_id'])
        ->where('user_id',$request['can_id'])->first();
        if(!$liked)
        {
            \DB::table('user_like_candidates')->insert(
                array(
                       'employer_id' =>$request['employer_id'], 
                       'user_id'    =>$request['can_id']
                )
            );
        return response()->json(['data' => [],"Message"=> "like Successfully",
        "Success"=>true] ); 

        }
        else
        {
        $liked->delete();
        return response()->json(['data' => [],"Message"=> "dislike Successfully",
        "Success"=>true] ); 
        }
    }
    //employer Registeration
    
    
    public function employerregistation(Request $request)
    {
     
    // try
    // {
        $code = 1000;
        $points=0;
        $countcoins=['name'=>$request['name'],

        'email'=>$request['email'],
        'phone'=>$request['phone'],
        'password' => bcrypt($request['password']),
        'last_name'=>$request['last_name'],
        'job_for'=>$request['job_for'],
        'country_id'=>$request['country_id'],
        'city_id'=>$request['city_id'],
        'type'=>$request['type'],
        'remember_token'=>$request['remember_token'],
        'first_name'=>$request['first_name'],
];
  //dd($countcoins);
foreach ( $countcoins as   $value) {

    if($value != null && $value !="0")
    {

        $points ++;
    }

}
$totalpoints=$points*5;

$country=$request['country_id'];
$city=$request['city_id'];
 
 

  
        $countryQueryCityID=Country::where('name',$country)->first();
        $citynam = New City;
     
        //get the code value;
        $lastUser =  \DB::table('users')->orderBy('id', 'desc')->first();
        if($lastUser)
        {
            $code = $lastUser->code++;
        }
    //*code generated*/

    //**create user
        $user = User::create(['name'=>$request['name'],'remember_token'=>$request['remember_token'],
        'email'=>$request['email'],'password' => bcrypt($request['password']),
        'type'=>'employer','code'=>$code]);
    //**user created

        $input = $request->all();
        if($user)
        {
            $emptype= EmployerProfile::create(['city_id'=>$city,
            'type'=>$request['type'],'first_name'=>$request['name'],
            'last_name'=>$request['last_name'],'country_id'=>$country,
            'user_id'=>$user->id,'phone'=>$request['phone'],'coins'=>$totalpoints]);
         
          
           // dd($emp);
         
        }


     \App\Company::create(['name'=>$request['name'],'size'=>'5','Country_id'=>$country,'lat'=>'0','lang'=>'0','Created_by'=>$user->id,'industry_id'=>'0']);

        // $user->notify(new AddEmployer($emptype));
        //Sending Mail after adding
         $data=array('Email'=>$request['email']);
         Mail::send('emails.NewJob', $data, function($message) use ($data) {
         $message->to('Social@maidandhelper.com');
         $message->subject('new job is added ');
 
        });
 
 
        //Sending Mail after regestration
        $data=array('Email'=>$request['email']);
        Mail::send('emails.RegestrationSucess', $data, function($message) use ($data) {
        $message->to($data['Email']);
        $message->subject('registeration completed');

        });
        $user=EmployerProfile::with(['country','city'])
          ->join('users','users.id','=','employer_profiles.user_id')
          ->where('user_id', $user->id)
          ->select('*','users.*')
          ->first();
      return response()->json(['user' => $user,'Message'=>'',"Success"=>true]);

      
//}    
    // catch(Exception $e) 
    //     {
    //      dd
    //      }
        
        
    }
      public function updatecandidate(Request $request)
    { 
        
    }

    
    public function easycanreg(Request $request)
    { 

       // request('email')
        // try
        // {
      $code = 1000;
      $vedio_path='';
      $lastUser =  \DB::table('users')->orderBy('id', 'desc')->first();
      //check Email
      $ExsistUser =  \DB::table('users')
      ->where('email',$request['email'])
      ->first();
      if($ExsistUser !=null || $ExsistUser !=[])
      {
        return response()->json(['Data'=>[],"Message"=> "Email already Exsist",
        "Success"=>true]);
      }
     
      if($lastUser)
      {
        $code = $lastUser->code++;
      }

      $user = User::create(['name'=>$request['name'],
      'email'=>$request['email'],
      'password' => bcrypt($request['password']),
      'type'=>'candidate','code'=>$code]);
      $input = $request->all();

    //   if($request->hasFile('video_file'))
    //   {
    //       $vedio_path = $this->saveFile($request['video_file'],$user);
    //       $input['vedio_path']=$vedio_path;
         
    //   }
    //   else
    //   {
         
        
    //   }
      $input['vedio_path']='';
      unset($input['name'],$input['email'],$input['password']);
      $input['user_id']= $user->id;
      $countcoins=['name'=>$request['name'],
      'email'=>$request['email'],'remember_token'=>$request['email'],
      'industry_id'=>$request['industry_id'],
      'job_id'=>$request['job_id'],
      'gender'=>$request['gender'],
      'password' => bcrypt($request['password']),
      'country_id'=>$request['country_id'],
      'coins'=>$request['coins'],
     
];




$CandidateInfo= CandidateInfo::create($input);

$prefered_location = $request['prefered_location_id'];
if($prefered_location)
{
    $locations = [];
    array_push($locations,$prefered_location);
    //dd($prefered_location);
    if($request['prefered_location_ids'])
    {
        foreach ($request['prefered_location_ids'] as $key => $prefered) {
            array_push($locations,$prefered);
        }
    }

    foreach (array_unique($locations) as $key => $loc) {
       \App\PreferedLocation::create(['user_id'=>$user->id,'country_id'=>$loc]);
    }
    
}

      $user->notify(new Candidate_notification($CandidateInfo));
      //Sending Mail after adding
      $data=array('Email'=>$request['email']);
      Mail::send('emails.NewEmployer', $data, function($message) use ($data) {
      $message->to('Social@maidandhelper.com');
      $message->subject('new user is added ');
      });
       //Sending Mail after regestration
      $data=array('Email'=>$request['email']);
      Mail::send('emails.RegestrationSucess', $data, function($message) use ($data) {
      $message->to($data['Email']);
      $message->subject('registeration completed');
      });
    //  $user = Auth::user(); "Message"=> "Email already Exsist",
          $user=CandidateInfo::with(['country','religion','job','industry','canjob','nationality','CanExperince','getCandidateLang','getCandidatePreferedLoc','skills'])
          ->join('users','users.id','=','candidate_infos.user_id')
          ->where('user_id', $user->id)
          ->select('*','users.*')
          ->first();
      return response()->json(['user' => $user,'Message'=>'',"Success"=>true]); 
//         }    
//   catch(Exception $e) 
//       {
//         return response()->json(['error'=>'Something Wrong'], 401);
//        }
    }
    public function saveUploadedFile($file, $user){
        $filename = time().$file->getClientOriginalName();
        $type = $file->getMimeType();
        $extension = $file->getClientOriginalExtension();
        $path = 'uploads/'.$user->id;
        $destPath ='uploads/'.$user->id.'/'.$filename;
        if(!\File::exists($path)) {
            // path does not exist
            \File::makeDirectory($path, $mode = 0777, true, true);
        }
        $success =$file->move($path,$filename);
       // $destPath = str_replace( $destPath);
        return $destPath;
    }
    
    public function saveFile($file, $user){
        try
        {


        $filename = 'video'.time().$file->getClientOriginalName();
        $type = $file->getMimeType();
        $extension = $file->getClientOriginalExtension();
        $path = 'videos/'.$user->id;
        $destPath ='videos/'.$user->id.'/'.$filename;
        if(!\File::exists($path)) {
            // path does not exist
            \File::makeDirectory($path, $mode = 0777, true, true);
        }
        $success =$file->move($path,$filename);
       // $destPath = str_replace( $destPath);
        return $destPath;
        }    
    catch(Exception $e) 
        {
            return response()->json(['error'=>'Something Wrong'], 401);
        }
    }
public function getallsucess()
{
    $Data =SuccessStories::all();
     return response()->json(['sucessstory' =>$Data,"Message"=> "","Success"=>true]); 
    
}
public function getsucessbyuser(Request $request)
{
    $Data =SuccessStories::where('user_id',$request->user_id)->first();
     return response()->json(['sucessstory' =>$Data,"Message"=> "","Success"=>true]); 
    
}

public function getappliesjob(Request $request)
{
     $Data=[];
    $favourite=DB::table('job_applications')->where('user_id',$request['user_id'])->get();

        foreach ($favourite as $Matching) {
            
            $Dataset=PostJob::with(['Industry','job','country','getJobLanguage','getJobSkill'])
            ->where('id',$Matching->job_post_id)
            ->first();
            
           array_push($Data, $Dataset); 
        } 
    
    
    
     return response()->json(['appliedjobs' =>$Data,"Message"=> "","Success"=>true]); 
}
    public function addsucessstoryEmp(Request $request)
    {
        
     $userid=DB::table('employer_profiles')->where('user_id',$request->user_id)->first();
        if($userid == null)
        {
            return response()->json(['Data' => [],"Message"=> "",
        "Success"=>false]); 
           
              
        }
        else{
             SuccessStories::create([
         'description'=>$request->description,
         'emp_id'=> $userid->id,
         'approval'=>1,
         'user_id'=>$request->user_id]);
   return response()->json(['Data' => [],"Message"=> "",
        "Success"=>true]); 
         
            
        }
         
    }
       public function addsucessstoryCan(Request $request)
    {
     $userid=DB::table('candidate_infos')->where('user_id',$request->user_id)->first();
    if($userid == null)
        {
          
           
            return response()->json(['Data' => [],"Message"=> "",
        "Success"=>false]); 
              
        }
        else{
          SuccessStories::create([
         'description'=>$request->description,
         'can_id'=> $userid->id,
         'approval'=>1,
         'user_id'=>$request->user_id]);
           
            return response()->json(['Data' => [],"Message"=> "",
        "Success"=>true]); 
        }
    }
    
    public function updateimage(Request $request)
    {
        try
            {
               $file = $request['file']; 
               $images = $request->file('images');
               $id =  $request->get('id');
               $imageName = $images->getClientOriginalName();
               $path=("upload/imgageslogo").$imageName;
                if (!file_exists($path)) {
                    $images->move(("upload/imgageslogo"),$imageName);
                    $q =User::where('id', $id)->first();
                        if ($q)
                        {
                            $user = User::find($q->id);
                            $user->logo = "upload/imgageslogo/".$imageName;
                            $user->save();
                            return response()->json(['user' => $q,"Message"=> "","Success"=>true] ); 
                        }
                    }
                else
                    {
                       $random_string = md5(microtime());
                       $images->move(public_path("upload/imgageslogo"),$random_string.".jpg");
                       $q =User::where('id',$id)->first();            
                            if ($q)
                            {
                                $user = User::find($q->id);
                                $user->logo = "/upload/imgageslogo/".$random_string.".jpg";
                                $user->save();
                                return response()->json(['user' => $q,"Message"=> "","Success"=>true] ); 
                            }
                       }
        }
        catch(Exception $e) 
        {
            return response()->json(['user' => [],"Message"=> "","Success"=>false] ); 
        }
    }
                //edit uploaded video
    public function updatemainvideo(request $request)
        {
            try
             {
                $blobInput = $request->file('video');
                $id=$request->get('id');
                $VideoName= $blobInput->getClientOriginalName();
                $path=("upload/video").$VideoName;
                $data =User::where('id',$id)->first();   
                if (!file_exists($path)) {
                $random_string = md5(microtime());
                $blobInput->move(("upload/video"),$VideoName);
                $q= CandidateInfo::where('user_id', $id)->limit(1)  // optional - to ensure only one record is updated.
                    ->update(array('vedio_path' => "upload/video/".$VideoName));
                return response()->json(['user' => $data,"Message"=> "","Success"=>true] );
                }
                else
                    {
                        $random_string = md5(microtime());
                        $blobInput->move(("upload/video"),$random_string.".webm");
                        $q= CandidateInfo::
                        where('user_id', $id)  // find your user by their email
                        ->limit(1)  // optional - to ensure only one record is updated.
                        ->update(array('vedio_path' => "upload/video/".$random_string.".webm "));
                        
                        return response()->json(['user' => $data,"Message"=> "","Success"=>true] );
                    }
                }    
            catch(Exception $e) 
                {
                    return response()->json(['user' => [],"Message"=> "","Success"=>false] ); 
                } 
        }
        public function newvideo(request $request)
        {
            try
             {
                $blobInput = $request->file('video');
                $id=$request->get('id');
                $VideoName= $blobInput->getClientOriginalName();
                $path=("upload/video").$VideoName;
                $data =User::where('id',$id)->first();   
                if (!file_exists($path)) {
                $random_string = md5(microtime());
                $blobInput->move(("upload/video"),$VideoName);
                $videoInsert=\DB::table('videos')->insert(
                    array(
                           'Path' =>"upload/video/".$VideoName, 
                           'User_Id'    =>$id
                    )
                );
                return response()->json(['user' => $data,"Message"=> "","Success"=>true] );
                }
                else
                    {
                        $random_string = md5(microtime());
                        $blobInput->move(("upload/video"),$random_string.".webm");
                        $videoInsert=\DB::table('videos')->insert(
                            array(
                                    'Path' =>"upload/video/".$random_string.".webm ", 
                                    'User_Id'    =>$id
                            )
                        );
                        
                        return response()->json(['user' => $data,"Message"=> "","Success"=>true] );
                    }
                }    
            catch(Exception $e) 
                {
                    return response()->json(['user' => [],"Message"=> "","Success"=>false] ); 
                } 
        }  
        public function deletevideo(request $request)
        {
            try
             {
                $id=$request->get('id');
                $video=\DB::table('videos')
                ->where('id',$id)
                ->delete();
                return response()->json(['user' => [],"Message"=> "","Success"=>true] );
                }    
            catch(Exception $e) 
                {
                    return response()->json(['user' => [],"Message"=> "","Success"=>false] ); 
                } 
        } 
        
    public function topcandidate() 
    { 
       
        $Data =CandidateInfo::with(['country','religion','job','industry','canjob','nationality','CanExperince','getCandidateLang','getCandidatePreferedLoc','skills'])
          ->join('users','users.id','=','candidate_infos.user_id')
          ->select('*','users.*')
            ->orderBy('candidate_infos.created_at', 'DEC')->where('seen','=',1)->limit(10)->get();
        
       return response()->json(['top_candidate' => $Data,"Message"=> "",
        "Success"=>true]);  
    }
     public function revlantjobwithoutReg(Request $request)
    {
    $MatchingJobs=[];
    //Matching job 
    $JobName=Job::where('id',$request['job_id'])->select('name')->first();
    $JobNameLiks=Job::where('name', 'LIKE', '%'.$JobName->name.'%')->get();
    foreach($JobNameLiks as $JobNameLiks)
    {
        $MatchingJo = PostJob::with(['Industry','job','Currency','country','getJobLanguage','getJobSkill'])
        ->where('job_id',$JobNameLiks->id)
        ->orwhere('job_id',$request['industry_id'])
          ->orwhere('country_id',$request['country_id'])
           ->get();    
        foreach ($MatchingJo as $Matching) {
           array_push($MatchingJobs, $Matching); 
        }  
    }    
    return response()->json(['relevant_jobs' => $MatchingJobs,"Message"=> "",
    "Success"=>true]); 
        
    }
    
    
    public function postjob(Request $request)
    {           
        
               
            $user=EmployerProfile::where('user_id',$request->user_id)->first();
            if( $user==null)
            {
                  return response()->json(['Data' => [],"Message"=> "",
    "Success"=>false]);  
            }
            else
            {
                $userdata=User::where('id',$request->user_id)->first();
           
                $input= $request->all();
                $input['job_for']=$user->type;
                unset($input['skill_ids'],$input['language_ids']);
                $input['created_by']= $request->user_id;
                $job = PostJob::create($input);
                if($request['language_ids'])
                {
                    foreach ($request['language_ids'] as $key => $lang) {
                        # code...
                        \App\JobLanguage::create(['language_id'=>$lang,'job_id'=>$job->id]);
                    }
                }
                if($request['skill_ids'])
                {
                    foreach ($request['skill_ids'] as $key => $skill) {
                        # code...
                        \App\JobSkill::create(['job_id'=>$job->id, 'skill_id'=>$skill])
                        ;
                    }
                }
               
                    $data=array('Email'=>$userdata->email);
                    Mail::send('emails.NewJob', $data, function($message) use ($data) {
                    $message->to('Social@maidandhelper.com');
                    $message->subject('new job is added ');
                    });
          
                  return response()->json(['Data' => [],"Message"=> "",
    "Success"=>true]);  
            }
              
                
}
    
    
    
    public function confirmationmail(Request $request)
    {
            $data=array('Email'=>$request->email);
                    Mail::send('emails.NewJob', $data, function($message) use ($data) {
                    $message->to('Social@maidandhelper.com');
                    $message->subject('new job is added ');
                    });
                  return response()->json(['Data' => [],"Message"=> "",
                   "Success"=>true]); 
    }
    
    
       //update candidate informations
    public function updateFullReg(EditFullCanRegisterFormRequest $request,$id)
    {

        try
        {
          $videopoint=0;
          $logopoint=0;
          $cvgpoint=0;
          $skillpoint=0;
          $langpoint=0;
          $edupoint=0;
          $points=0;
              $code = 1000;
            
              //get the code value;
              $lastUser =  \DB::table('users')->orderBy('id', 'desc')->first();
              if($lastUser)
              {
                  $code = $lastUser->code++;
              }
              //*code generated*/
      
      
             //**update user
              $userid=CandidateInfo::where('id',$id)->select('user_id')->first();
              $uid=$userid->user_id;
            
              $user = user::find($uid);
              
              $user->name = $request->first_name;
              $user->email = $request->email;
              $user->password = Hash::make($request->password);
              $user->type = 'candidate';
              $user->code = $code;
      
              $user->save();
      
             
               $cv_path = "";
               $logo = "";

            
              $user->languages()->sync( $request['language_ids'] );
           $langpoint=5;
               
              $user->skills()->sync( $request['skill_ids'] );
               if($request['language_ids'])
               {
                
                   $langpoint=5;
               }
               if($request['skill_ids'])
               {
                   
                   $skillpoint=5;
               }
               if($request['Eductionlevel'])
               {
                    $eduction= \App\Educational::find($request['Eductionlevel']);
                  if($eduction ==null)
                    {
                         $educt= New  \App\Educational;
                      $educt->level = $request->Eductionlevel;
                        $educt->user_id =$user->id;
                        $educt->save();  
                    }
                    else
                    {
                       $eduction->level = $request->Eductionlevel;
                        $eduction->user_id =$user->id;
                        $eduction->save();  
                    }
       
       }
       
               $countcoins=['name'=>$request['first_name'],
               'email'=>$request['email'],
               'password' => bcrypt($request['password']),
               'last_name'=>$request['last_name'],
               'phone_number'=>$request['phone_number'],
               'religion_id'=>$request['religion_id'],
               'birthdate'=>$request['birthdate'],
               'visa_type'=>$request['visa_type'],
               'visa_expire_date'=>$request['visa_expire_date'],
               'job_id'=>$request['job_id'],
               'industry_id'=>$request['industry_id'],
               'country_id'=>$request['country_id'],
               'gender'=>$request['gender'],
               'martial_status'=>$request['martial_status'],
               'descripe_yourself'=>$request['descripe_yourself'],
               'looking_for_job'=>$request['looking_for_job'],
               'nationality_id'=>$request['nationality_id'],
               'working_in'=>$request['working_in'],
               'start_date'=>$request['start_date'],
               'end_date'=>$request['end_date'],
               'employer_nationality_id'=>$request['employer_nationality_id'],
               'company_name'=>$request['company_name'],
               'country_id'=>$request['work_country_id'],
               'salary'=>$request['salary'],
               'MaxSalary'=>$request['MaxSalary'],
               'role'=>$request['role'],
               $request['prefered_location_id']
       ];
         
       foreach ( $countcoins as   $value) {
       
           if($value != null && $value !="0")
           {
       
               $points ++;
           }
       
       }
       
       $totalpoints=$points*5+$cvgpoint+$edupoint+$skillpoint+$langpoint;
     
       
                  $candinfo=CandidateInfo::find($request->id);
                  $candinfo->last_name = $request->last_name;
                  $candinfo->phone_number = $request->phone_number;
                  $candinfo->religion_id = $request->religion_id;
                  $candinfo->salary = $request->salary;
                  $candinfo->MaxSalary = $request->MaxSalary;
                  $candinfo->birthdate = $request->birthdate;
                  $candinfo->visa_type = $request->visa_type;
                  $candinfo->visa_expire_date = $request->visa_expire_date;
                  $candinfo->job_id = $request->job_id;
                  $candinfo->industry_id = $request->industry_id;
                  $candinfo->country_id = $request->country_id;
                  $candinfo->gender = $request->gender;
                  $candinfo->CurrencyId = $request->CurrencyId;
                  $candinfo->Eductionlevel = $request->Eductionlevel;
                  $candinfo->martial_status = $request->martial_status;
                  $candinfo->descripe_yourself = $request->descripe_yourself;
                  $candinfo->looking_for_job = $request->looking_for_job;
                  $candinfo->nationality_id = $request->nationality_id;
                 
                  $candinfo->user_id =$user->id;
                  $candinfo->coins = $totalpoints;
                
                 $candinfo->save();
    $idEx=CandidateExperience::where('user_id',$user->id)->select('id')->first();

if($idEx != null)
{
      //updates in can_experinence
                $canexperience=CandidateExperience::FindOrFail($idEx->id);

                $canexperience->working_in = $request->working_in;
                $canexperience->start_date = $request->start_date;
                $canexperience->end_date = $request->end_date;
                $canexperience->employer_nationality_id = $request->employer_nationality_id;
                $canexperience->company_name = $request->company_name;
                $canexperience->country_id = $request->work_country_id;
                $canexperience->salary = $request->salarymaybe;
                $canexperience->role = $request->role;
                $canexperience->user_id = $user->id;
                  
                $canexperience->save();
              
            //update in location
            $prefered_location = $request['prefered_location_id'];
            if($prefered_location)
            {
                $locations = [];
                array_push($locations,$prefered_location);
                //dd($prefered_location);
                if($request['prefered_location_ids'])
                {
                    foreach ($request['prefered_location_ids'] as $key => $prefered) {
                        # code...
                        array_push($locations,$prefered);
                    }
                }

                foreach (array_unique($locations) as $key => $loc) {
                    # code...
                    $location= \App\PreferedLocation::find($id);
                    $location->user_id = $user->id;
                    $location->country_id = $loc;
                    $location->save();
              
                }
                
            }
}

else
{

                  $canexperience= New CandidateExperience;
                $canexperience->working_in = $request->working_in;
                $canexperience->start_date = $request->start_date;
                $canexperience->end_date = $request->end_date;
                $canexperience->employer_nationality_id = $request->employer_nationality_id;
                $canexperience->company_name = $request->company_name;
                $canexperience->country_id = $request->work_country_id;
                $canexperience->salary = $request->exsalary;
                $canexperience->role = $request->role;
                $canexperience->user_id = $user->id;
                   
                $canexperience->save();
                
            //update in location
            $prefered_location = $request['prefered_location_id'];
            if($prefered_location)
            {
                
     
           $user->preferedLocations()->attach($prefered_location);
 
                
            }

}
              
            
                 return redirect('/home');
            
        }    
        catch(Exception $e) 
            {
             return redirect('/');
             }
         }

}