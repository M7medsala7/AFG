<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class packageattribute extends Model
{
   public $table="package_attribute";
}
