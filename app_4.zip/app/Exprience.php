<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Exprience extends Model
{
    public $table="exprience";
}
